#!/bin/bash
source ~/.bashrc

#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/CIFAR10 --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 25 --experiment-name cif10_alexnet_median_25s
#mv log/predictions_info.txt log/cif10_alexnet_median_25s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/CIFAR10 --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 50 --experiment-name cif10_alexnet_median_50s
#mv log/predictions_info.txt log/cif10_alexnet_median_50s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/CIFAR10 --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 100 --experiment-name cif10_alexnet_median_100s
#mv log/predictions_info.txt log/cif10_alexnet_median_100s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/CIFAR10 --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 200 --experiment-name cif10_alexnet_median_200s
#mv log/predictions_info.txt log/cif10_alexnet_median_200s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/CIFAR10 --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 500 --experiment-name cif10_alexnet_median_500s
#mv log/predictions_info.txt log/cif10_alexnet_median_500s/pred_info.txt

#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/CIFAR10 --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 1 --experiment-name cif10_alexnet_1s
#mv log/predictions_info.txt log/cif10_alexnet_1s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/MNIST --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 1 --experiment-name mnist_alexnet_1s
#mv log/predictions_info.txt log/mnist_alexnet_1s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/MNIST --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 10 --experiment-name mnist_alexnet_10s
#mv log/predictions_info.txt log/mnist_alexnet_10s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/MNIST --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 10 --experiment-name mnist_alexnet_median_10s
#mv log/predictions_info.txt log/mnist_alexnet_median_10s
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/MNIST --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 25 --experiment-name mnist_alexnet_median_25s
#mv log/predictions_info.txt log/mnist_alexnet_median_25s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/MNIST --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 50 --experiment-name mnist_alexnet_median_50s
#mv log/predictions_info.txt log/mnist_alexnet_median_50s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/MNIST --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 100 --experiment-name mnist_alexnet_median_100s
#mv log/predictions_info.txt log/mnist_alexnet_median_100s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/MNIST --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 200 --experiment-name mnist_alexnet_median_200s
#mv log/predictions_info.txt log/mnist_alexnet_median_200s/pred_info.txt
#python template/RunMe.py --runner-class dropout_testing --gpu-id 3 --output-folder log --dataset-folder datasets/MNIST --lr 0.1 --model-name alexnet --ignoregit --epochs 20 --multi-run 5 --dropout-samples 500 --experiment-name mnist_alexnet_median_500s
#mv log/predictions_info.txt log/mnist_alexnet_median_500s/pred_info.txt
